package cn.zswltech.preserver.infrastructure.mapper;

import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.ExtractDataBeforeDO;

public interface ExtractDataBeforeMapper extends IMapper<ExtractDataBeforeDO> {
}