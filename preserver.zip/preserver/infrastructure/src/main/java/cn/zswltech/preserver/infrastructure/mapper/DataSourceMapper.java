package cn.zswltech.preserver.infrastructure.mapper;

import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.DataSourceDO;

public interface DataSourceMapper extends IMapper<DataSourceDO> {
}