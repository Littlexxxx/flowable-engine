package cn.zswltech.preserver.infrastructure.mapper;

import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.AuditRuleDO;

public interface AuditRuleMapper extends IMapper<AuditRuleDO> {
}