package cn.zswltech.preserver.infrastructure.mapper;


import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.FieldGroupDO;

public interface FieldGroupMapper extends IMapper<FieldGroupDO> {
}