package cn.zswltech.preserver.infrastructure.mapper;

import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.ServiceConfigDO;

public interface ServiceConfigMapper extends IMapper<ServiceConfigDO> {
}