package cn.zswltech.preserver.infrastructure.mapper;

import cn.zswltech.preserver.infrastructure.common.IMapper;
import cn.zswltech.preserver.infrastructure.dataobject.ExtractDataAfterDO;

public interface ExtractDataAfterMapper extends IMapper<ExtractDataAfterDO> {
}