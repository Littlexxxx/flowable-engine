package cn.zswltech.preserver.infrastructure.dataobject;

import java.util.Date;
import javax.persistence.*;

@Table(name = "zswltech_audit_rule")
public class AuditRuleDO {
    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 规则名称
     */
    private String name;

    /**
     * 数据源id
     */
    @Column(name = "datasource_id")
    private Integer datasourceId;

    /**
     * 有效时间开始
     */
    @Column(name = "gmt_begin")
    private String gmtBegin;

    /**
     * 有效时间结束
     */
    @Column(name = "gmt_end")
    private String gmtEnd;

    /**
     * 创建时间
     */
    @Column(name = "gmt_create")
    private Date gmtCreate;

    /**
     * 创建人
     */
    @Column(name = "created_by")
    private String createdBy;

    /**
     * 更新时间
     */
    @Column(name = "gmt_update")
    private Date gmtUpdate;

    /**
     * 更新人
     */
    @Column(name = "updated_by")
    private String updatedBy;

    /**
     * 规则详情json
     */
    @Column(name = "rule_detail")
    private String ruleDetail;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取规则名称
     *
     * @return name - 规则名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置规则名称
     *
     * @param name 规则名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取数据源id
     *
     * @return datasource_id - 数据源id
     */
    public Integer getDatasourceId() {
        return datasourceId;
    }

    /**
     * 设置数据源id
     *
     * @param datasourceId 数据源id
     */
    public void setDatasourceId(Integer datasourceId) {
        this.datasourceId = datasourceId;
    }

    /**
     * 获取有效时间开始
     *
     * @return gmt_begin - 有效时间开始
     */
    public String getGmtBegin() {
        return gmtBegin;
    }

    /**
     * 设置有效时间开始
     *
     * @param gmtBegin 有效时间开始
     */
    public void setGmtBegin(String gmtBegin) {
        this.gmtBegin = gmtBegin;
    }

    /**
     * 获取有效时间结束
     *
     * @return gmt_end - 有效时间结束
     */
    public String getGmtEnd() {
        return gmtEnd;
    }

    /**
     * 设置有效时间结束
     *
     * @param gmtEnd 有效时间结束
     */
    public void setGmtEnd(String gmtEnd) {
        this.gmtEnd = gmtEnd;
    }

    /**
     * 获取创建时间
     *
     * @return gmt_create - 创建时间
     */
    public Date getGmtCreate() {
        return gmtCreate;
    }

    /**
     * 设置创建时间
     *
     * @param gmtCreate 创建时间
     */
    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    /**
     * 获取创建人
     *
     * @return created_by - 创建人
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * 设置创建人
     *
     * @param createdBy 创建人
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * 获取更新时间
     *
     * @return gmt_update - 更新时间
     */
    public Date getGmtUpdate() {
        return gmtUpdate;
    }

    /**
     * 设置更新时间
     *
     * @param gmtUpdate 更新时间
     */
    public void setGmtUpdate(Date gmtUpdate) {
        this.gmtUpdate = gmtUpdate;
    }

    /**
     * 获取更新人
     *
     * @return updated_by - 更新人
     */
    public String getUpdatedBy() {
        return updatedBy;
    }

    /**
     * 设置更新人
     *
     * @param updatedBy 更新人
     */
    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * 获取规则详情json
     *
     * @return rule_detail - 规则详情json
     */
    public String getRuleDetail() {
        return ruleDetail;
    }

    /**
     * 设置规则详情json
     *
     * @param ruleDetail 规则详情json
     */
    public void setRuleDetail(String ruleDetail) {
        this.ruleDetail = ruleDetail;
    }
}