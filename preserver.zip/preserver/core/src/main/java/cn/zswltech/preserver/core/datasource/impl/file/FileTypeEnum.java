package cn.zswltech.preserver.core.datasource.impl.file;

/**
 * @author: xinhao.hu
 * @date: 2022/5/17 5:38 下午
 * @description:
 **/
public enum FileTypeEnum {
    EXCEL,
    CSV,
    ;
}
