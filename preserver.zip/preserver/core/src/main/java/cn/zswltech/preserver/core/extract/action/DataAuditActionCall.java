package cn.zswltech.preserver.core.extract.action;

import cn.zswltech.preserver.core.audit.AuditRequest;
import cn.zswltech.preserver.core.audit.AuditResponse;
import cn.zswltech.preserver.core.audit.DataAuditEngine;
import cn.zswltech.preserver.core.cache.AuditRuleCache;
import cn.zswltech.preserver.core.datamap.DataMappingEngine;
import cn.zswltech.preserver.core.datamap.context.DataMappingContext;
import cn.zswltech.preserver.core.datamap.context.DataMappingResponse;
import cn.zswltech.preserver.core.extract.context.ExtractContext;
import cn.zswltech.preserver.core.extract.context.ExtractResponse;
import cn.zswltech.preserver.core.rule.rule.Rule;
import cn.zswltech.preserver.data.source.domain.DataSourceModel;
import org.apache.commons.compress.utils.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author: xinhao.hu
 * @date: 2022/5/25 5:05 下午
 * @description:
 **/
@Component
public class DataAuditActionCall implements ExtractActionCall {

    @Autowired
    private AuditRuleCache auditRuleCache;

    @Autowired
    private DataAuditEngine dataAuditEngine;

    @Autowired
    private DataMappingEngine dataMappingEngine;

    @Override
    public void call(ExtractContext context, ExtractResponse response) {
        if (context.getExtractDatas().size()==0) {
            return;
        }
        DataSourceModel dataSourceModel = context.getDataSourceModel();
        Rule rule = auditRuleCache.get(dataSourceModel.getRuleId()).getRule();
        AuditRequest auditRequest = AuditRequest.builder()
                .auditData(context.getExtractDatas())
                .rule(rule)
                .build();

        AuditResponse auditResponse = dataAuditEngine.audit(auditRequest);
        response.setAuditResponse(auditResponse);

        // TODO 判断是否进入数据映射，现直接调用
        List<Map<String, Object>> acceptData = Lists.newArrayList();
        auditResponse.getAcceptData().forEach(t -> acceptData.add(t.getOriginData()));

        DataMappingContext dataMappingContext = DataMappingContext.builder()
                .unExecuteDatas(acceptData)
                .executedDatas(Lists.newArrayList())
                .extractId(context.getExtractId())
                .seviceConfig(context.getServiceConfig())
                .build();
        DataMappingResponse dataMappingResponse = dataMappingEngine.execute(dataMappingContext);
        response.setDataMappingResponse(dataMappingResponse);
    }

    @Override
    public String getName() {
        return "DataAudit";
    }
}
