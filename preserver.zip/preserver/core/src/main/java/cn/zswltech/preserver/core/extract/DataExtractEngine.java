package cn.zswltech.preserver.core.extract;

import cn.zswltech.preserver.admin.middle.data.domain.before.ExtractDataBefore;
import cn.zswltech.preserver.admin.middle.data.domain.before.ExtractDataBeforeRepository;
import cn.zswltech.preserver.admin.middle.data.service.ExtractDataBeforeService;
import cn.zswltech.preserver.core.extract.action.ExtractActionCall;
import cn.zswltech.preserver.core.extract.context.ExtractContext;
import cn.zswltech.preserver.core.extract.context.ExtractResponse;
import cn.zswltech.preserver.core.extract.factory.DataExtractFactory;
import cn.zswltech.preserver.data.source.domain.DataSourceModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author: xinhao.hu
 * @date: 2022/5/25 4:23 下午
 * @description:
 **/
@Component
public class DataExtractEngine {

    @Autowired
    private DataExtractFactory dataExtractFactory;

    @Autowired
    private ExtractDataBeforeRepository extractDataBeforeRepository;


    public void extract(ExtractContext extractContext, ExtractResponse extractResponse, ExtractActionCall extractActionCall){
        String extractSelect = extractContext.getExtractSelect();
        String extractType = extractContext.getExtractType();
        DataExtract dataExtract = dataExtractFactory.getDataExtract(extractSelect);
        List<Map<String,Object>> extractDatas;
        // TODO 存储extractId
        extractContext.setExtractId(1);
        switch(extractType){
            case "entire":
                extractDatas = dataExtract.entireExtract(extractContext);
                break;
            case "increment":
                extractDatas = dataExtract.incrementExtract(extractContext);
                break;
            default:
                throw new RuntimeException("do not have this extract type");
        }

        extractContext.setExtractDatas(extractDatas);
        extractResponse.setExtractDatas(extractDatas);

        extractActionCall.call(extractContext,extractResponse);
    }

}
