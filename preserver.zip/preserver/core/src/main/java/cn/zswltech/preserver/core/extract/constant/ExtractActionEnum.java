package cn.zswltech.preserver.core.extract.constant;

/**
 * @author: xinhao.hu
 * @date: 2022/5/30 1:47 下午
 * @description:
 **/
public enum ExtractActionEnum {

    DataAudit,

}
