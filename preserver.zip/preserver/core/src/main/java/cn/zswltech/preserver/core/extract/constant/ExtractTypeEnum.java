package cn.zswltech.preserver.core.extract.constant;

/**
 * @author: xinhao.hu
 * @date: 2022/5/19 11:00 上午
 * @description:
 **/
public enum ExtractTypeEnum {
    LOCAL,
    REMOTE,
    MYSQL,
    ;

    public static ExtractTypeEnum getExtractType(String name){
        return ExtractTypeEnum.valueOf(name);
    }
}
