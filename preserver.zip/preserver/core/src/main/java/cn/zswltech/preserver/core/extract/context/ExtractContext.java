package cn.zswltech.preserver.core.extract.context;

import cn.zswltech.preserver.data.source.domain.DataSourceModel;
import cn.zswltech.preserver.service.config.domain.ServiceConfig;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * @author: xinhao.hu
 * @date: 2022/5/25 4:54 下午
 * @description:
 **/
@Data
public class ExtractContext {

    private String extractSelect;

    private String extractType;

    private DataSourceModel dataSourceModel;

    private ServiceConfig serviceConfig;

    private List<Map<String,Object>> extractDatas;

    private int extractId;
}
