package cn.zswltech.preserver.core.datamap.context;

/**
 * @author: xinhao.hu
 * @date: 2022/5/18 3:24 下午
 * @description:
 **/
public class DataMappingResponse {
}
