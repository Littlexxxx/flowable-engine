package cn.zswltech.preserver.admin.middle.data.domain.before;

/**
 * @author: xinhao.hu
 * @date: 2022/5/25 3:03 下午
 * @description:
 **/
public enum ExtractDataBeforeStatusEnum {

    EXTRACTED,
    UNEXTRACT,
    ;
}
