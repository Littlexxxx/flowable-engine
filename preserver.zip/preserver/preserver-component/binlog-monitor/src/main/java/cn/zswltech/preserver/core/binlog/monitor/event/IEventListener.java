package cn.zswltech.preserver.core.binlog.monitor.event;

import com.github.shyiko.mysql.binlog.BinaryLogClient;

public interface IEventListener extends BinaryLogClient.EventListener {
}
