package cn.zswltech.preserver.core.rule.rule.detail;

/**
 * @author: xinhao.hu
 * @date: 2022/5/16 5:31 下午
 * @description:
 **/
public interface DetailCallable {
    IDetail call();
}
